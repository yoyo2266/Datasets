# Building Pro > 2023-11-16 12:32pm
https://universe.roboflow.com/elte-kcfyn/building-pro

Provided by a Roboflow user
License: CC BY 4.0

